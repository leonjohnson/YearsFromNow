import RealmSwift

class Categories: Object {
    dynamic var name = ""
    dynamic var addedByUser = true
    dynamic var colorName = ""
}
