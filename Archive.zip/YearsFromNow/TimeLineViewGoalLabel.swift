//
//  TimeLineViewGoalLabel.swift
//  YearsFromNow
//
//  Created by Leon Johnson on 23/09/2015.
//  Copyright © 2015 Leon Johnson. All rights reserved.
//

import UIKit

class TimeLineViewGoalLabel: UILabel {

    /*
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func drawRect(rect: CGRect) {
        // Drawing code
    }
    */

}
